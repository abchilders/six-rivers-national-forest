# six-rivers-national-forest
Creating a mapping website for the Six Rivers National Forest that allows the public to submit updates on trail conditions. 
