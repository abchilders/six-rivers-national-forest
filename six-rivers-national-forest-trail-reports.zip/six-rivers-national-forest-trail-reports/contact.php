<!DOCTYPE html>

<html>
<head>
    <meta charset="utf-8">
    <title>Contact</title>
	
	<link href="http://nrs-projects.humboldt.edu/~st10/styles/normalize.css"
          type="text/css" rel="stylesheet" />

    <link href="site-style.css" type="text/css" rel="stylesheet" />

</head>

<body>
	<?php require_once("site-header.html"); 
	?>
	
	<h1> Contact Us </h1>
	<p> Developers:
		<ul>
			<li><a href="mailto:rha25@humboldt.edu?Subject=Six%20Rivers%20National%20Forest">Rawan Almakhloog </a></li> 
			<li><a href="mailto:abc66@humboldt.edu?Subject=Six%20Rivers%20National%20Forest">Alex Childers</a> </li> 
			<li><a href="mailto:jlm1455@humboldt.edu?Subject=Six%20Rivers%20National%20Forest">John Mackin </li> 
			<li><a href="mailto:snp242@humboldt.edu?Subject=Six%20Rivers%20National%20Forest">Sthephany Ponce </li> 
		</ul>
	</p> 

</body>

</html>
