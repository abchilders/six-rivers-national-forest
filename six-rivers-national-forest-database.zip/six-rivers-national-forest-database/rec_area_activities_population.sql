/* Group 3A */

prompt ===
prompt Populating Rec_Area_Activities
prompt ===

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11443), 'Campground Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11443), 'RV Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11443), 'Day Hiking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11471), 'Dispersed Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11471), 'Lake and Pond Fishing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11471), 'Swimming'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11472), 'Lake and Pond Fishing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11473), 'Lake and Pond Fishing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 79264), 'River and Stream Fishing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 64830), 'River and Stream Fishing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 64830), 'Boating - Non-Motorized'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11552), 'Backpacking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11552), 'Viewing Plants'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 81414), 'Backpacking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 81414), 'Day Hiking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 81414), 'Dispersed Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11558), 'Campground Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11558), 'Lake and Pond Fishing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11558), 'Day Hiking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11442), 'RV Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11442), 'Day Hiking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11442), 'Campground Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11476), 'Backpacking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11476), 'Horse Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11476), 'Horse Riding'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11520), 'Group Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11520), 'Day Hiking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11520), 'Mountain Biking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11520), 'Horse Riding'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11520), 'OHV Trail Riding'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11520), 'Backpacking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11520), 'Scenic Driving'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11520), 'Lake and Pond Fishing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11520), 'Campground Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11520), 'River and Stream Fishing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 80106), 'Swimming'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 80106), 'River and Stream Fishing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 80106), 'Boating - Non-Motorized'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11522), 'Campground Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11524), 'Campground Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11447), 'Cabin Rentals'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 75350), 'Swimming'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 75350), 'Boating - Non-Motorized'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 75350), 'River and Stream Fishing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 64828), 'River and Stream Fishing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 64828), 'Swimming'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 64828), 'Picnicking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 64828), 'Boating - Non-Motorized'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11557), 'Campground Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11440), 'RV Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11440), 'Day Hiking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11440), 'Cabin Rentals'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11440), 'Backpacking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11440), 'Horse Riding'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11440), 'Viewing Plants'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11440), 'Interpretive Areas'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11440), 'Mountain Biking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11440), 'Tubing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11440), 'Horse Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11440), 'Campground Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11440), 'Swimming'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11440), 'River and Stream Fishing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11440), 'Lake and Pond Fishing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11440), 'Boating - Non-Motorized'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11440), 'Dispersed Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11444), 'Campground Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11444), 'Boating - Non-Motorized'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11444), 'RV Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11444), 'Day Hiking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 79294), 'Boating - Non-Motorized'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11519), 'Tubing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11519), 'River and Stream Fishing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11519), 'Boating - Non-Motorized'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11519), 'Swimming'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11519), 'Picnicking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 64831), 'Boating - Non-Motorized'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11560), 'Campground Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 25814), 'River and Stream Fishing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 25814), 'Day Hiking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 25814), 'Tubing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 25814), 'Campground Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 25814), 'Backpacking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 25814), 'Boating - Non-Motorized'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 25814), 'Horse Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 25814), 'Horse Riding'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 25814), 'Dispersed Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11474), 'Lake and Pond Fishing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11523), 'Campground Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11553), 'Day Hiking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11553), 'Backpacking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11553), 'Horse Riding'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11553), 'OHV Trail Riding'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11553), 'Lake and Pond Fishing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11553), 'Dispersed Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11553), 'Campground Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11553), 'River and Stream Fishing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11559), 'Campground Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11559), 'Group Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11561), 'Campground Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11582), 'Lake and Pond Fishing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11445), 'River and Stream Fishing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11445), 'Campground Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11445), 'Day Hiking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11454), 'Mountain Biking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11454), 'Backpacking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11454), 'Horse Riding'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 25818), 'River and Stream Fishing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 25818), 'Boating - Non-Motorized'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11479), 'Campground Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11479), 'Day Hiking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11480), 'Campground Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11446), 'Day Hiking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11446), 'Campground Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11446), 'RV Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 25817), 'Boating - Non-Motorized'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 25817), 'Campground Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11477), 'Backpacking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11477), 'Horse Riding'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11477), 'Day Hiking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11477), 'Mountain Biking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11477), 'Tubing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11477), 'Scenic Driving'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11477), 'Campground Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11477), 'Lake and Pond Fishing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11477), 'Boating - Non-Motorized'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11477), 'River and Stream Fishing'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11477), 'Picnicking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11477), 'Swimming'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 59665), 'Swimming'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 59665), 'Boating - Non-Motorized'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 59665), 'Picnicking'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11555), 'Campground Camping'); 

insert into Rec_Area_Activities
values 
((select internal_id 
from Rec_Area 
where  recareaid = 11556), 'Campground Camping'); 

