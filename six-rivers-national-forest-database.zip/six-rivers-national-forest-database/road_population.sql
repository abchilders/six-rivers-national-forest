prompt ===
prompt Populating Road table
prompt ===

insert into Road(id,internal_id,is_motor_vehicle_use_road,is_national_forest_system_road,adminorg,bmp,emp,fid,gis_miles,globalid,jurisdicti,name,route_stat,rte_cn,security_id,seg_length,shape_len,surface_type,system)
values
('158640',1,'y','n',51054,0,0.084,158640,0.08,'{561B6AE5-ADC6-448B-9618-31DE487788B6}','FS - FOREST SERVICE','CHINQUAPIN BUTTE', 'EX - EXISTING', 13232010395, 514, 0.084,0.001569334,'NAT - NATIVE MATERIAL','NFSR - NATIONAL FOREST SYSTEM ROAD');



insert into Road(id,internal_id,is_motor_vehicle_use_road,is_national_forest_system_road,adminorg,bmp,emp,fid,gis_miles,globalid,jurisdicti,name,route_stat,rte_cn,security_id,seg_length,shape_len,surface_type,system)
values
('159966',2,'y', 'n',51053, 6.24, 9.86,159966, 3.655, '{F8163E20-CC36-4884-8AB3-AD81F45CCD59}', 'FS - FOREST SERVICE', 'HAPPY CAMP MTN RD', 'EX - EXISTING', 568629000000, 514, 3.62, 0.060766998, 'AC - ASPHALT','NFSR - NATIONAL FOREST SYSTEM ROAD');

prompt ===
prompt Finished populating Road
prompt ===
