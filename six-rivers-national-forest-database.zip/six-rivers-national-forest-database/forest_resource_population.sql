prompt ===
prompt Creating sequence to generate internal ids. 
prompt ===

drop sequence internal_id_seq; 

create sequence internal_id_seq
minvalue 0
start with 0; 

prompt ===
prompt Populating Forest_Resource table. 
prompt ===

insert into Forest_Resource
values
(internal_id_seq.nextval, 'road'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'road'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

insert into Forest_Resource
values
(internal_id_seq.nextval, 'rec_area'); 

