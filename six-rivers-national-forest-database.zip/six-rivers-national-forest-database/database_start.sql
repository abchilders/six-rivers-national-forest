/* Group 3A */

/* This script runs all necessary SQL scripts to get the database tables
   created, populated, and operational. */ 

start table_creation.sql

start forest_resource_population.sql

start rec_area_population.sql

start road_population.sql

start motor_vehicle_road_population.sql

start rec_area_activities_population.sql

