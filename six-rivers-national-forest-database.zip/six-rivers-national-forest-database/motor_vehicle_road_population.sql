prompt ===
prompt Populating Motor_Vehicle_Use_Road table
prompt ===

insert into Motor_Vehicle_Use_Road(internal_id,atv,atv_dateso,bus,bus_dateso,districtna,field_id,forestname,fourwd_gt5,fourwd_g_1,highcleara,highclea_1,motorcycle,motorcyc_1,motorhome,motorhome_,other_oh_1,other_oh_2,other_ohv_,other_ohv1,otherwheel,otherwhe_1,passengerv,passenge_1,sbs_symbol,seasonal,symbol,ta_symbol,tracked_oh,tracked__1, tracked__2,tracked__3,truck,truck_date,twowd_gt50,twowd_gt_1)                                                                                              
values
(1,'open','01/01-12/31','open','01/01-12/31','Mad River Ranger District,'28N56','Six Rivers National Forest','open','01/01-12/31','open','01/01-12/31','open','01/01-12/31','open','01/01-12/31','open','01/01-12/31','open','01/01-12/31','open','01/01-12/31','open','01/01-12/31','Road, Not Maintained for Passenger Car','yearlong',1,6,'open','01/01-12/31','open','01/01-12/31','open','01/01-12/31','open','01/01-12/31')


insert into Motor_Vehicle_Use_Road(internal_id,bus,bus_dateso,districtna,field_id,forestname,highcleara,highclea_1,motorhome,motorhome_,passengerv,passenge_1,sbs_symbol,seasonal,symbol,ta_symbol,truck,truck_date)		
values
(2,'open','01/01-12/31','Lower Trinity Ranger District','07N26','HAPPY CAMP MTN RD','open','01/01-12/31','open','01/01-12/31','open','01/01-12/31','Paved Road','yearlong',3,3,'open','01/01-12/31')

prompt ===
prompt Finished populating motor_vehicle_use_road
prompt ===